# Vertus Bot

Auto Claim for Vertus Telegram Bot


# Features

- [x] Auto Claim Vert token
- [x] Auto Start Mining
- [x] Auto Claim Daily Bonus
- [x] Auto Claim Card Balance
- [x] Auto Upgrade Farm, Storage & Population
- [x] Auto Uograde Cards
- [x] Auto Calim Ads Reward
- [x] Auto Complete Task
- [x] Multi Account Support

# Register

Click the following url to register : [Vertus Bot](https://t.me/vertus_app_bot/app?startapp=5496274031)

# How to Use
- [Windows](#windows)
- [Linux](#linux)
- [Termux](#termux)
## Windows 

1. Make sure you computer was installed python and git.
   
   python site : [https://python.org](https://python.org)
   
   git site : [https://git-scm.com/](https://git-scm.com/)

2. Clone this repository
   ```shell
   git clone https://github.com/BlackDragonHacker/Vertus.git
   ```

3. goto tomarketod directory
   ```
   cd Vertus
   ```

4. install the require library
   ```
   python -m pip install -r pip.txt
   ```

5. Edit `data.txt`, input you auth token in `data.txt` file

6. execute the main program 
   ```
   python Vertus.py
   ```

## Linux

1. Make sure you computer was installed python and git.
   
   python
   ```shell
   sudo apt install python3 python3-pip
   ```
   git
   ```shell
   sudo apt install git
   ```

2. Clone this repository
   
   ```shell
   git clone https://github.com/BlackDragonHacker/Vertus.git
   ```

3. goto tomarketod directory

   ```shell
   cd Vertus
   ```

4. Install the require library
   
   ```
   python3 -m pip install -r pip.txt
   ```

5. Edit `data.txt`, input you auth token in `data.txt` file

6. execute the main program 
   ```
   python Vertus.py
   ```

## Termux

1. Make sure you termux was installed python and git.
   
   python
   ```
   pkg install python
   ```

   git
   ```
   pkg install git
   ```

2. Clone this repository
   ```shell
   git clone https://github.com/BlackDragonHacker/Vertus.git
   ```

3. goto tomarketod directory
   ```
   cd Vertus
   ```

4. install the require library
   ```
   python -m pip install -r pip.txt
   ```

5. Edit `data.txt`, input you auth token in `data.txt` file

6. execute the main program 
   ```
   python Vertus.py
   ```


# How to get auth token

`Network` < `get-data` < `Headers` <`authorization`

then copy only `query_id=` or `user=` paste `data.txt` file

<a href="https://ibb.co/VMhPWv2"><img src="https://i.ibb.co/c2p7cND/Screenshot-20240709-193541-Gallery-2.jpg" alt="Screenshot-20240709-193541-Gallery-2" border="0"></a>
# Thank you
